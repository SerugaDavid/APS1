package APS1.Izziv2;

class CollectionException extends Exception {
    public CollectionException(String msg) {
        super(msg);
    }
}