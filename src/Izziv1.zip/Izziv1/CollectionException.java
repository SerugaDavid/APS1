package APS1.Izziv1;

class CollectionException extends Exception {
    public CollectionException(String msg) {
        super(msg);
    }
}
