package APS1.Izziv6;

interface Comparable {
    public int compareTo(Oseba o);
}