package APS1.Izziv7;

interface Comparable {
    public int compareTo(Oseba o);
}