package APS1.Izziv7;

class CollectionException extends Exception {
    public CollectionException(String msg) {
        super(msg);
    }
}